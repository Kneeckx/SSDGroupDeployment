<div class="row">
    <div class="col-lg-12">
        <div class="alert alert-success">You have successfully logged in as <strong><?php echo $_SESSION['user']['username']; ?></strong></div>
    </div>
</div>