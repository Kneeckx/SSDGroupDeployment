Attribution
===========

Applications like DIWA are only possible because of the many free and open source projects out there.

DIWA and its developers use the following free frameworks / services / projects (in alphabetical order):

* [Bootstrap](https://getbootstrap.com)
* [Font Awesome](http://fontawesome.io)
* [GitHub](https://github.com)
* [Glyphicons](https://glyphicons.com)
* [jQuery](https://jquery.org)
* [Mozilla Firefox](https://www.mozilla.org)
* [OWASP](https://www.owasp.org)
* [PHP](https://secure.php.net)

Do you miss anything here? Contact me: [snsttr @ Github](https://github.com/snsttr) 