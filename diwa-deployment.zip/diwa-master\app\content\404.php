<?php
if(!headers_sent()) {
    header('HTTP/1.1 404 Not Found');
}
?>

<div class="row">
    <div class="col-lg-12">
        <h1>404 - Page not found</h1>
        <p class="text-center">
            <a href="./" class="btn btn-primary">Back to index</a>
        </p>
    </div>
</div>